
  # Driver Delivery Dashboard (Copy)

  This is a code bundle for Driver Delivery Dashboard (Copy). The original project is available at https://www.figma.com/design/JDJT5GOE9Faa7x43eFsVhf/Driver-Delivery-Dashboard--Copy-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  